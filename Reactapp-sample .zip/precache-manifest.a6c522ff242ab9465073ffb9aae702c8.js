self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "67e4d5da5073a0ba60ce72a01c3feee4",
    "url": "/index.html"
  },
  {
    "revision": "99a7a0e2bf3d55f82ad9",
    "url": "/static/css/main.5f361e03.chunk.css"
  },
  {
    "revision": "652a599d1a99efccd345",
    "url": "/static/js/2.a430f49c.chunk.js"
  },
  {
    "revision": "e88a3e95b5364d46e95b35ae8c0dc27d",
    "url": "/static/js/2.a430f49c.chunk.js.LICENSE.txt"
  },
  {
    "revision": "99a7a0e2bf3d55f82ad9",
    "url": "/static/js/main.4f4a69a4.chunk.js"
  },
  {
    "revision": "415e9bcf6c081ea50565",
    "url": "/static/js/runtime-main.f8c5b4be.js"
  },
  {
    "revision": "5d5d9eefa31e5e13a6610d9fa7a283bb",
    "url": "/static/media/logo.5d5d9eef.svg"
  }
]);